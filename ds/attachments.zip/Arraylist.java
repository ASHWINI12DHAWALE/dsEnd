import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Arraylist
{
	 public static void main(String[] args)
	 {
		 ArrayList<Customer> list=new ArrayList<Customer>();
		 Scanner sc=new Scanner(System.in);
		 
		 list.add(new Customer("prt",1,10000));
		 list.add(new Customer("abc",2,30000));
		 list.add(new Customer("pst",9,80000));
		 //String name, int id, int salary
		 Collections.sort(list,new A());
		 System.out.println("sorted list is");

		 System.out.println(list);

		 
		 Collections.reverse(list);
		 System.out.println("sorted list in reverse");
		 System.out.println(list);

		 
		 
		 
	 }
	

}
