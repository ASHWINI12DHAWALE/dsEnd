
public class MakeTrip implements Comparable<MakeTrip>
{
   private int id;
   private String name;
   private String Source;
   private String destination;
   
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "MakeTrip [id=" + id + ", name=" + name + ", Source=" + Source + ", destination=" + destination + "]";
	}
	public MakeTrip(int id, String name, String source, String destination) {
		this.id = id;
		this.name = name;
		Source = source;
		this.destination = destination;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	@Override
	public int compareTo(MakeTrip o) {
		if(this.getId()>o.getId())
		{
			return 1;
		}
		else if(this.getId()<o.getId())
		{
			return -1;
		}
		else
		{
			return 0;
		}
		
	}
   
}
