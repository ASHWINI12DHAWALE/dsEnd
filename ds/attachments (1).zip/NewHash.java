import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class NewHash 
{
   public static void main(String []args)
   {
	  String wish;
	  HashMap<MakeTrip, String> l1=new HashMap<MakeTrip, String>();
	   Scanner sc=new Scanner(System.in);
	   int ch;
	   do
	   {
		   System.out.println("Enter 1.for insert 2.for search");
		   ch=sc.nextInt();
		   switch(ch)
		   {
		   case 1:
			System.out.println("enter the no");
			int n=sc.nextInt();
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter id");
				int id=sc.nextInt();
				

				System.out.println("Enter name");
				String name=sc.next();

				System.out.println("Enter source");
				String source=sc.next();

				System.out.println("Enter desti");
				String destination=sc.next();
				
				
				l1.put(new MakeTrip(id, name, source, destination),"123");
			}
			break;
		   case 2:
			 System.out.println("Enter Name");
			 String name=sc.next();
			 for(Map.Entry<MakeTrip, String> e1:l1.entrySet())
			 {
				 System.out.println(e1.getKey());
			 }
			  break;
			   
		   case 3:
			   TreeMap<MakeTrip,String> sorted = new TreeMap<>(l1);
			   for(Map.Entry<MakeTrip, String> l2:sorted.entrySet())
				 {
					 System.out.println(l2.getKey());
				 }
			   break;
			   
		   }
		   System.out.println("Do you want to continue");
		   wish=sc.next();
	   }while(wish.equals("y") || wish.equals("Y"));
   }
}
