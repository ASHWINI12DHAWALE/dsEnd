import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Array 
{
   public static void main(String args[])
   {
	  Coin c1;
	  Scanner sc=new Scanner(System.in);
	  int n,price,year;
	  String country,Name,wish;
      ArrayList<Coin> s1=new ArrayList<Coin>(); 
	  int ch;
	  do
	  {
		  System.out.println("Enter 1. for Add Detail 2.for Serach Coin country vice 3. for show list in ascending order");
		  ch=sc.nextInt();
		  switch(ch)
		  {
		  case 1:
		   System.out.println("Enter the number in which do yo want to add coin Detail");
		      n=sc.nextInt();
		      for(int i=0;i<n;i++)
		      {
		          System.out.println("Enter country name");
		          country=sc.next();

		          System.out.println("Enter price");
		          price=sc.nextInt();

		          System.out.println("Enter year");
		          year=sc.nextInt();
		           
		          s1.add(new Coin(price,country,year));
		      }
		      break;
		  case 2:
			 System.out.println("Enter Country Name");
			 Name=sc.next();
			 System.out.println(Name);
			 for(int i=0;i<s1.size();i++)
			 {
				 if(s1.get(i).getCountry().equals(Name))
				 {
					 System.out.println(s1.get(i).getPrice());	 
					 System.out.println(s1.get(i).getYear());
				 }
			 }
			 break;
		  case 3:
			     Collections.sort(s1,new Sortbyroll()); 
				 for(int i=0;i<s1.size();i++)
				 {
					System.out.println(s1.get(i).getCountry());
				 }
				 break;
		  }
		  System.out.println("do you want to continue");
		  wish=sc.next();
	   
	      
	  }while(wish.equals("Y") || wish.equals("y"));
	
   }
}
