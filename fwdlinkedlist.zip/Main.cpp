// LinkedList_1005_demo.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include "pch.h"
#include <iostream>
#include"Node.h"
#include"LinkedList.h"
#include<conio.h>

int main()
{
	Linkedlist l1;

	l1.insert(10);
	l1.insert(50);
	l1.insert(30);
	l1.insert(40);
	l1.insert(70);
	l1.insertpos(15,4);
	l1.insertpos(23,5);
	l1.remove(15);
	l1.remove(30);
	l1.removepos(23,3);
	l1.removepos(40,3);
	l1.display();
	//l1.displayrev(head);
	_getch();
	return 0;

}
