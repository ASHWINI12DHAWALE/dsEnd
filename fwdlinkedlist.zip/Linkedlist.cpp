#include"pch.h"
#include"LinkedList.h"

Linkedlist::Linkedlist()
{
	head = NULL;
}
bool Linkedlist::insert(int data)
{
	Cnode *newNode = new Cnode(data);
	
	if (newNode == NULL) {
		return false;
	}
	if (head == NULL) {
		head = newNode;
		return true;
}
	Cnode  *temp = head;

	while(temp->getnext()!=NULL)
	{
		temp = temp->getnext();
	}

	temp->setnext(newNode);
	return true;
}

bool Linkedlist::insertpos(int data, int pos)
{
	if (pos<= 0) {
		return false;
	}
	Cnode *newNode = new Cnode(data);
	if (newNode == NULL)
	{
		return false;
	}
	if (pos == 1)
	{
		newNode->setnext(head);
		
		head = newNode;
		return true;

	}

	Cnode *temp = head;
	for (int i = 1; i < pos - 1; i++) 
	{

		if (temp == NULL) 
		{
			delete newNode;
		}
		temp = temp->getnext();
		
		
	}
	newNode->setnext(temp->getnext());
	temp->setnext(newNode);
	return true;
}
bool Linkedlist::remove(int data )
{
	if (head == NULL) {
		return false;
	}
	if ( head->getdata()==data) {
		Cnode *temp = head;
		head =temp->getnext();
		delete temp;
		return true;
	}
	Cnode *prev, *temp;
	prev = temp = head;
	while (temp->getdata() != data) {
		prev = temp;
		temp = temp->getnext();
		if (temp == NULL) {
			return false;
		}
	
	}
	prev->setnext(temp->getnext());
	delete temp;
	return true;


}bool Linkedlist::removepos(int data, int pos)
{
	if (head == NULL) {
	return false;
	}

	if (pos == 1) {
		Cnode *temp = head;
		head = temp->getnext();
		delete temp;
		return true;
	}
	Cnode *temp=head;
	for (int i = 1; i < pos - 1; i++)
	{
		if (temp == NULL) {
			return false;
		}
		temp = temp->getnext();
	}
	Cnode *del = temp->getnext();
	temp->setnext(del->getnext());
	delete del;
	return true;
	}
//
//bool Linkedlist:: displayrev(Cnode *){
//
//
	void Linkedlist::display()
	{
		Cnode *temp = head;

		while (temp != NULL)
		{

			cout << temp->getdata() << " ";
			temp = temp->getnext();
		}

	
}