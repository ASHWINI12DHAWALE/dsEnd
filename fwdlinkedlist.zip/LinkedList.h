#ifndef LINK_h
#define LINK_h

#include"pch.h"
#include"Node.h"

class Linkedlist
{
private:
	int pos;
	Cnode *head;

public:
	Linkedlist();
	bool insert(int data);
	bool insertpos(int, int);
	bool remove(int);
	bool removepos(int, int);
	/*bool displayrev(Cnode *);*/
	void display();

};
#endif
