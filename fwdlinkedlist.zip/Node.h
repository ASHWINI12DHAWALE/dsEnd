#ifndef NOD_H
#define NOD_H

#include"pch.h"
#include<iostream>
#include<stdio.h>
using namespace std;

class Cnode {
private:
	int data;
	Cnode *next;

public:
	Cnode(int);
	int getdata();
	void setdata(int);
	Cnode* getnext();
	void setnext(Cnode*);
	~Cnode();
};
#endif

