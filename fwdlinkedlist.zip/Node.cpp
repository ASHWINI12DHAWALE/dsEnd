#include"pch.h"
#include"Node.h"

Cnode::Cnode(int data)
{
	this->data = data;
	next = NULL;
}

int Cnode:: getdata()
{
	return data;
}
void Cnode::setdata(int data)
{
this->data = data;
 }

Cnode* Cnode::getnext()
{
	return next;
}
void Cnode::setnext(Cnode *next)
{
	this->next = next;
}
Cnode::~Cnode()
{

}