#include"node.h"
# include"programmer.h"
#include"salesmanager.h"

Node::Node()
{
	int choice;

	cout << "\n1.programmer   \n2.Salesmaneger \n 3.employee" << endl;
	cout << "Enter the choice  :";
	cin >> choice;
	switch (choice)
	{
	case 3:
		this->e = new Employee(13, 5000);
		break;
	case 1:
		this->e = new Programmer(12,20000,200,100);
		break;
	case 2:
		this->e = new SalesManager(11,30000,100);
		break;
	default:exit(0);
	}
		this->next = NULL;
}

Employee* Node::gete()
{
	return this->e;
}
void Node::sete(Employee*)
{
	this->e = e;
}
Node* Node::getnext()
{
	return this->next;
}
void  Node::setnext(Node*)
{
	this->next= next;
}
