#ifndef SALES_H
#define SALES_H
#include"emp.h"

class SalesManager :public Employee
{
protected:
	double incentives;
public:
	SalesManager();
	SalesManager(int,float,double);
	void display();

};
#endif