
#ifndef MNGR_h
#define MNGR_h

#include"emp.h"

class Programmer :public Employee
{
protected:
	double fa, pa;
public:
	Programmer();
	Programmer(int,float,double, double);
	
	void display();
	//double computeSalary();
};
#endif
