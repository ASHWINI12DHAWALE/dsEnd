#ifndef EMP_H
#define EMP_H
#include<iostream>
using namespace std;

class Employee
{
protected:
	int id;
	float sal;
public:
	Employee(int, float);
	int getid();
	float getsal();
	void setid(int);
	void setsal(float);
    virtual void display();
};
#endif