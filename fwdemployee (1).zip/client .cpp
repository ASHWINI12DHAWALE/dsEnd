#include"linkedlist.h"
#include<conio.h>
int main()
{
	Linkedlist l1;
	int ch;
	while (1)
	{
		cout << "\n 1.insert  \n2.display";
		cout << "\n enter choice";
		cin >> ch;

		switch (ch)
		{
		default:
			exit (0);
			break;
		case 1:
			l1.insert();
			break;
		case 2:
			l1.display();
			break;
		}
	}
	/*l1.insert();
	l1.display();*/
	_getch();
	return 0;
}