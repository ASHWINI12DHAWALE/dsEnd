#include"linkedlist.h"
# include"programmer.h"
#include"salesmanager.h"

Linkedlist::Linkedlist()
{
	this->head = NULL;
}
bool Linkedlist::insert()
{
	Node* newnode = new Node();
	
		if (newnode == NULL)
		{
			return false;
		}
		if (head == NULL)
		{
			head = newnode;
			return true;
		}
		Node* temp = head;
		while (temp->getnext() != NULL)
		{
			temp = temp->getnext();
		}
		temp->setnext(newnode);
		return true;
}
int Linkedlist::display()
{
	if (head == NULL)
	{
		return false;
	}
	Node* temp = head;
	while (temp != NULL)
	{
		temp->gete()->display();
		temp = temp->getnext();
	}
	return true;
}