#include"salesmanager.h"


SalesManager::SalesManager(int id,float sal,double incentives) 
	:Employee(id,sal)	
{
	this->incentives = incentives;
}

void SalesManager::display()
{
	Employee::display();

	cout << "\n Incentives::" << this->incentives;
}
//double SalesManager::computeSalary()
//{
//	return (this->salary + (this->nos*this->comm)
//		+ (this->fa + this->pa));
//}