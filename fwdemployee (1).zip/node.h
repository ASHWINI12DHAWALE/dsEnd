#ifndef EMP1_H
#define EMP1_H

#include"emp.h"
 
class Node
{
private:
	Employee *e;
	Node* next;
public:
	Node();
	Employee* gete();
	void sete(Employee*);
	Node* getnext();
	void setnext(Node*);
	void display();
};
#endif