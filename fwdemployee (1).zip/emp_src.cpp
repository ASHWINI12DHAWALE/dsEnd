#include"emp.h"
//Employee::Employee()
//{
//	this->id = 0;
//	this->sal = 0;
//}
Employee::Employee(int id, float sal)
{
	this->id = id;
	this->sal= sal;
}
int Employee::getid()
{
	return this->id;
}
float Employee::getsal()
{
	return this->sal;
}

void  Employee::setid(int id)
{
	this->id =id ;
}
void Employee::setsal(float sal)

{
	this->sal = sal;
}
void Employee::display()
{
	cout << "\nid =" << this->id
		<< "\nsalary ="<<this->sal;
}