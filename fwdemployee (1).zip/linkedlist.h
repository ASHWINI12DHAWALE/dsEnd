#include"node.h"

class Linkedlist
{
	Node* head;
public:
	Linkedlist();
	bool insert();
	int display();
};
