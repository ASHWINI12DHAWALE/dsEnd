#include"programmer.h"


Programmer::Programmer(int id,float sal,double fa, double pa)
	: Employee(id,sal)
{
	this->fa = fa;
	this->pa = pa;
}



void Programmer::display()
{
	Employee::display();
	cout << "\n Food all::" << this->fa;
	cout << "\n PEtrol All::" << this->pa;
}

//double Manager::computeSalary()
//{
//	return this->salary + this->fa + this->pa;
//}