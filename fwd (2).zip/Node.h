#ifndef NOD_h
#define NOD_h

#include<iostream>
using namespace std;

class Node
{
	int data;
	Node *next;
public:
	Node(int);
	int getdata();
	void setdata(int);
	Node *getnext();
	void setnext(Node*);
};

#endif
