#include"Node.h"
#include"Stack.h"
#include<conio.h>
int main()
{
	Stack q;
	q.enqueue(10);
	q.display();
	q.enqueue(20);
	q.display();
	q.enqueue(30);
	q.display();
	q.enqueue(40);
	q.display();
	q.enqueue(50);
	q.display();
	cout << "\ndequeue" << endl;
	q.dequeue();
	q.display();
	cout << "\ndequeue" << endl;
	q.dequeue();
	q.display();
	cout << "\ndequeue" << endl;
	q.dequeue();
    q.display();


	_getch();
	return 0;
}