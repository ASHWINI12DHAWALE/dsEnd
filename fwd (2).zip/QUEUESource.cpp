#include"Queue.h"
#include"Node.h"

Queue::Queue()
{
	this->front= 0;
	this->rear =0;
}
bool Queue::enqueue(int data)
{
	Node* nN = new Node(data);

	if (nN == NULL)
	{
		return false;
	}
	if(this->rear==NULL)
	{ 
	this->rear = this->front = nN;
	this->rear = nN;
	
	}
	this->rear->setnext(nN);
	this->rear = nN;
	return true;
}
bool Queue::dequeue()
{
	if (front == NULL)
	{
		return false;
	}
	Node* del = this->front;
	this->front = this->front->getnext();
	delete[] del;
	if (this->front == NULL)
	{
		this->rear = NULL;
	}
	return true;
}
void Queue::display()
{
	Node* temp;
	temp = this->front;
	while (temp!= NULL)
	{
		cout << temp->getdata() << " ";
		temp=temp->getnext();
	}
}