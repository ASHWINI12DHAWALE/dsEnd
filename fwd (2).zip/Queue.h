#ifndef QUE_h
#define QUE_h

#include"Node.h"
#include<iostream>
using namespace std;

class Queue
{
	Node *front, *rear;
public:
	Queue();
	bool enqueue(int);
	bool dequeue();
	void display();

};
#endif