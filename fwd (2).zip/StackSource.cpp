#include"Stack.h"
#include"Node.h"

Stack::Stack()
{
	this->top= 0;
	
}
bool Stack::enqueue(int data)
{
	Node* nN = new Node(data);

	if (nN == NULL)
	{
		return false;
	}
	if (this->top == NULL)
	{
		this->top = nN;
	}
	this->top->setnext(nN);
	this->top = nN;
	this->prev = this->top;
	return true;
}
bool Stack::dequeue()
{
	if (top == NULL)
	{
		return false;
	}
	Node* del = this->top;
	this->top = this->top->getnext();
	delete[] del;
	
	return true;
}
void Stack::display()
{
	Node* temp,*prev;
	temp = this->top;
	if(temp!=this->prev)
	{
		cout << temp->getdata() << " ";
		temp=temp->getnext();
	}
}