#ifndef QUE_h
#define QUE_h

#include"Node.h"
#include<iostream>
using namespace std;

class Stack
{
	Node *top;
public:
	Stack();
	bool enqueue(int);
	bool dequeue();
	void display();

};
#endif