#include"Node.h"

Node::Node(int data)
{
	this->data = data;
	this->next = NULL;
}
Node* Node::getnext()
{
	return this->next;
}
void Node::setnext(Node* next)
{
	this->next = next;
}
int Node::getdata()
{
	return this->data;
}
void Node::setdata(int data)
{
	this->data= data;
}